<?php
/**
 * PHPUnit
 *
 * Copyright (c) 2010-2011, Sebastian Bergmann <sb@sebastian-bergmann.de>.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in
 *     the documentation and/or other materials provided with the
 *     distribution.
 *
 *   * Neither the name of Sebastian Bergmann nor the names of his
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @package    PHPUnit_Selenium
 * @author     Sebastian Bergmann <sb@sebastian-bergmann.de>
 * @copyright  2010-2011 Sebastian Bergmann <sb@sebastian-bergmann.de>
 * @license    http://www.opensource.org/licenses/bsd-license.php  BSD License
 * @link       http://www.phpunit.de/
 * @since      File available since Release 1.0.0
 */

/**
 * Implementation of the Selenium RC client/server protocol.
 *
 * @package    PHPUnit_Selenium
 * @author     Sebastian Bergmann <sb@sebastian-bergmann.de>
 * @copyright  2010-2011 Sebastian Bergmann <sb@sebastian-bergmann.de>
 * @license    http://www.opensource.org/licenses/bsd-license.php  BSD License
 * @version    Release: 1.0.3
 * @link       http://www.phpunit.de/
 * @since      Class available since Release 1.0.0
 */
class PHPUnit_Extensions_SeleniumTestCase_TestingBotDriver extends PHPUnit_Extensions_SeleniumTestCase_Driver
{
    protected $desiredCapabilities = array();
    protected $extension = "";
    public $apiData = array();

  	public function getSessionID()
  	{
  		return $this->sessionId;
  	}

    public function setDesiredCapabilities(array $capabilities)
    {
      $this->desiredCapabilities = array_merge($this->desiredCapabilities, $capabilities);
    }
  
    public function setPlatform($platform)
    {
      $this->setDesiredCapabilities(array('platform' => $platform));
    }
  
    public function setBrowserVersion($browserVersion)
    {
      $this->setDesiredCapabilities(array('version' => $browserVersion));
    }

    public function setExtra($extra) 
    {
      $this->apiData['extra'] = $extra;
    }

    public function setGroups(array $groups)
    {
      $this->apiData['groups'] = implode(',', $groups);
    }

    /**
     * @return string
     */
    public function start()
    {
      if ($this->browserUrl == NULL) {
          throw new PHPUnit_Framework_Exception(
            'setBrowserUrl() needs to be called before start().'
          );
      }
      
      $capabilities = array();
      if (!empty($this->desiredCapabilities))
      {
        foreach ($this->desiredCapabilities as $k => $v)
        {
          if (is_bool($v))
          {
            $v = $v ? "true" : "false";
          }
          $capabilities[] = $k . '=' . (String) $v;
        }
      }
      
      if (!isset($this->sessionId)) {
          $this->sessionId = $this->getString(
            'getNewBrowserSession',
            array($this->browser, $this->browserUrl, $this->extension, implode(';', $capabilities))
          );

          $this->doCommand('setTimeout', array($this->seleniumTimeout * 1000));
      }

      return $this->sessionId;
    }
	
    /**
     * Send a command to the Selenium RC server.
     *
     * @param  string $command
     * @param  array  $arguments
     * @return string
     * @author Seth Casana <totallymeat@gmail.org>
     */
    protected function doCommand($command, array $arguments = array())
    {
        $client_key = $this->testCase->getClientKey();
        $client_secret = $this->testCase->getClientSecret();

        $url = sprintf(
          'http://%s:%s/selenium-server/driver/?cmd=%s&client_key=%s&client_secret=%s',
          $this->host,
          $this->port,
          urlencode($command),
          $client_key,
          $client_secret
        );

        $numArguments = count($arguments);
        $postData = sprintf('cmd=%s', urlencode($command));
        for ($i = 0; $i < $numArguments; $i++) {
            $argNum = strval($i + 1);

            if ($arguments[$i] == ' ') {
                $postData .= sprintf('&%s=%s', $argNum, urlencode($arguments[$i]));
            } else {
                $postData .= sprintf('&%s=%s', $argNum, urlencode(trim($arguments[$i])));
            }
        }

        if (isset($this->sessionId)) {
            $postData .= sprintf('&%s=%s', 'sessionId', $this->sessionId);
        }

        $postData .= sprintf('&client_key=%s&client_secret=%s', $client_key, $client_secret);

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/x-www-form-urlencoded; charset=utf-8'
        ));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 60);

        $response = curl_exec($curl);
        $info     = curl_getinfo($curl);

        curl_close($curl);

        if (strstr($response, 'ERROR: ') == $response) {
            throw new RuntimeException($response);
        }

        if (!$response) {
            throw new RuntimeException(curl_error($curl));
        }

        if ($info['http_code'] != 200) {
            throw new RuntimeException(
              'The response from the Selenium RC server is invalid: ' .
              $response
            );
        }

        return $response;
    }
}
