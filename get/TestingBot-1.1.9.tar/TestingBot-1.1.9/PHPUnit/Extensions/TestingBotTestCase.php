<?php
/**
 * PHPUnit
 *
 * Copyright (c) 2010-2011, Sebastian Bergmann <sb@sebastian-bergmann.de>.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in
 *     the documentation and/or other materials provided with the
 *     distribution.
 *
 *   * Neither the name of Sebastian Bergmann nor the names of his
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @package    PHPUnit_Selenium
 * @author     Sebastian Bergmann <sb@sebastian-bergmann.de>
 * @copyright  2010-2011 Sebastian Bergmann <sb@sebastian-bergmann.de>
 * @license    http://www.opensource.org/licenses/bsd-license.php  BSD License
 * @link       http://www.phpunit.de/
 * @since      File available since Release 1.0.0
 */

require_once 'File/Iterator/Factory.php';

/**
 * TestCase class that uses Selenium to provide
 * the functionality required for web testing.
 *
 * @package    PHPUnit_Selenium
 * @author     Sebastian Bergmann <sb@sebastian-bergmann.de>
 * @copyright  2010-2011 Sebastian Bergmann <sb@sebastian-bergmann.de>
 * @license    http://www.opensource.org/licenses/bsd-license.php  BSD License
 * @version    Release: 1.0.3
 * @link       http://www.phpunit.de/
 * @since      Class available since Release 1.0.0
 *
 */

abstract class PHPUnit_Extensions_TestingBotTestCase extends PHPUnit_Extensions_SeleniumTestCase
{
    private $clientData = null;

     /**
     * This method is called when a test method did not execute successfully.
     *
     * @param Exception $e
     * @since Method available since Release 3.4.0
     */
    protected function onNotSuccessfulTest(Exception $e)
    {
        try
        {
            $data = array(
                'session_id' => $this->drivers[0]->getSessionID(),
                'client_key' => $this->getClientKey(),
                'client_secret' => $this->getClientSecret(),
                'status_message' => $this->getStatusMessage(),
                'success' => false,
                'name' => $this->toString(),
                'kind' => 1,
                'apiVersion' => 1
            );

            if (isset($this->drivers[0]->apiData['groups']))
            {
                $data['groups'] = $this->drivers[0]->apiData['groups'];
            }

            if (isset($this->drivers[0]->apiData['extra']))
            {
                $data['extra'] = $this->drivers[0]->apiData['extra'];
            }

            $this->apiCall($data);
        }
        catch (Exception $ex) {}

        parent::onNotSuccessfulTest($e);
    }

    protected function apiCall(array $postData)
    {
		$data = http_build_query($postData);

		if (function_exists('curl_init')) {
			$curl = curl_init();
			curl_setopt($curl, CURLOPT_URL, "http://testingbot.com/hq");
			curl_setopt($curl, CURLOPT_POST, true);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
			$response = curl_exec($curl);
			curl_close($curl);
		} else if (function_exists('fsockopen')) {
			$fp = fsockopen('testingbot.com', 80);

			fwrite($fp, "POST /hq HTTP/1.1\r\n");
			fwrite($fp, "Host: testingbot.com\r\n");
			fwrite($fp, "Content-Type: application/x-www-form-urlencoded\r\n");
			fwrite($fp, "Content-Length: ".strlen($data)."\r\n");
			fwrite($fp, "Connection: close\r\n");
			fwrite($fp, "\r\n");

			fwrite($fp, $data);
			fclose($fp);
		} else {
			echo "*** Please install cURL or enable fsockopen\n";
		}
    }

    /**
     * @param  array $browser
     * @return PHPUnit_Extensions_SeleniumTestCase_Driver
     * @since  Method available since Release 1.0.0
     */
    protected function getDriver(array $browser)
    {
        if (empty($browser)) { return; }
        
        if (isset($browser['name'])) {
            if (!is_string($browser['name'])) {
                throw new InvalidArgumentException(
                  'Array element "name" is no string.'
                );
            }
        } else {
            $browser['name'] = '';
        }

        if (isset($browser['browser'])) {
            if (!is_string($browser['browser'])) {
                throw new InvalidArgumentException(
                  'Array element "browser" is no string.'
                );
            }
        } else {
            $browser['browser'] = '';
        }

        if (isset($browser['host'])) {
            if (!is_string($browser['host'])) {
                throw new InvalidArgumentException(
                  'Array element "host" is no string.'
                );
            }
        } else {
            $browser['host'] = 'testingbot.com';
        }

        if (isset($browser['port'])) {
            if (!is_int($browser['port'])) {
                throw new InvalidArgumentException(
                  'Array element "port" is no integer.'
                );
            }
        } else {
            $browser['port'] = 4444;
        }

        if (isset($browser['timeout'])) {
            if (!is_int($browser['timeout'])) {
                throw new InvalidArgumentException(
                  'Array element "timeout" is no integer.'
                );
            }
        } else {
            $browser['timeout'] = 30;
        }

        if (isset($browser['httpTimeout'])) {
            if (!is_int($browser['httpTimeout'])) {
                throw new InvalidArgumentException(
                  'Array element "httpTimeout" is no integer.'
                );
            }
        } else {
            $browser['httpTimeout'] = 45;
        }

        $driver = new PHPUnit_Extensions_SeleniumTestCase_TestingBotDriver;
        $driver->setName($browser['name']);
        $driver->setBrowser($browser['browser']);
        $driver->setHost($browser['host']);
        $driver->setPort($browser['port']);
        $driver->setTimeout($browser['timeout']);
        $driver->setHttpTimeout($browser['httpTimeout']);
        $driver->setTestCase($this);
        $driver->setTestId($this->testId);
        $this->drivers[] = $driver;

        if (isset($browser['platform']))
        {
            $driver->setPlatform($browser['platform']);
        }
        
        if (isset($browser['browserVersion']))
        {
            $driver->setBrowserVersion($browser['browserVersion']);
        }

        $matches = array();
        preg_match('/(\d+)/i', $browser['browser'], $matches);
        if (!empty($matches))
        {
            $driver->setBrowserVersion((int) $matches[0]);
            $driver->setBrowser(str_replace($matches[0], "", $browser['browser']));
        }

        if (stripos($browser['browser'], "LATEST") !== false)
        {
            $driver->setBrowserVersion("LATEST");
            $driver->setBrowser(str_replace("LATEST", "", $browser['browser']));
        }

        return $driver;
    }

    public function stop()
    {
        if (!$this->hasFailed())
        {
            $data = array(
                'session_id' => $this->drivers[0]->getSessionID(),
                'client_key' => $this->getClientKey(),
                'client_secret' => $this->getClientSecret(),
                'status_message' => $this->getStatusMessage(),
                'success' => true,
                'name' => $this->toString(),
                'kind' => 1,
                'apiVersion' => 1
            );

            if (isset($this->drivers[0]->apiData['groups']))
            {
                $data['groups'] = $this->drivers[0]->apiData['groups'];
            }

            if (isset($this->drivers[0]->apiData['extra']))
            {
                $data['extra'] = $this->drivers[0]->apiData['extra'];
            }

            $this->apiCall($data);
        }

        parent::stop();
    }

    private function _getClientData()
    {
        if (is_null($this->clientData))
        {
            if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') 
            {
                $homeDir = substr(__FILE__, 0, 2);
            } 
            else
            {
                if (isset($_SERVER['HOME']))
                {
                    $homeDir = $_SERVER['HOME'];
                }
                else
                {
                    $homeDir = shell_exec('echo $HOME 2>&1');
                }
            }

            if (!file_exists($homeDir . DIRECTORY_SEPARATOR . '.testingbot'))
            {
                die('Please run testingbot configure "API_KEY:API_SECRET" first.');
            }
            $data = file_get_contents($homeDir . DIRECTORY_SEPARATOR . '.testingbot');
            list($client_key, $client_secret) = explode(':', $data);

            $this->clientData['client_key'] = $client_key;
            $this->clientData['client_secret'] = $client_secret;
        }

        return $this->clientData;
    }

    public function getClientSecret()
    {
        $data = $this->_getClientData();
        return rtrim($data['client_secret'], "\n");
    }

    public function getClientKey()
    {
        $data = $this->_getClientData();
        return $data['client_key'];
    }
}
