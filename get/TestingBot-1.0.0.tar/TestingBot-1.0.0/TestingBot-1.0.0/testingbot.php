#!/usr/bin/env php
<?php

	if (!defined('STDIN')) 
	{
		die('Please run this script in a shell/cli.');
	}
	
	$version = '1.0.0';
	
	function displayHelp()
	{
		global $version;
		echo "*** TestingBot v.$version http://www.testingbot.com ***\nThese commands are available:
		\nhelp\t\tdisplays this list
		\rversion\t\tcurrent version
		\rconfigure\tconfigure \"API_KEY:API_SECRET\"\n";
	}
	
	function configure()
	{
		global $argv;
		
		if (sizeof($argv) < 3)
		{
			die("Please use configure \"API_KEY:API_SECRET\"\n");
		}
		
		if (isset($_SERVER['HOME']))
		{
			$homeDir = $_SERVER['HOME'];
		}
		else
		{
			$homeDir = shell_exec('echo $HOME 2>&1');
		}
		
		file_put_contents($homeDir . '/.testingbot', $argv[2]);
		echo "Your account has been configured successfully. You can now start to run your Selenium tests.\n";
	}
	
	if (sizeof($argv) === 1)
	{
		displayHelp();
	}
	
	if (sizeof($argv) > 1)
	{
		switch ($argv[1]) 
		{
			default:
			case 'help':
				displayHelp();
				break;
			case 'configure':
				configure();
				break;
			case 'version':
				echo "Version v.$version http://www.testingbot.com\n";
		}
	}