<?php

	class TestingBot_setup_postinstall
	{
		var $_ui;
		var $_config;
		
		/**
		* @param PEAR_Config
		* @param PEAR_Frontend
		*/
		public function init(&$config, &$ui)
		{
			$this->_config = &$config;
			$this->_ui = &$ui;
			
			return true;
		}

		/**
		* @param array associative array of parameters
		* @param string paramgroup name
		* @param string either install or upgrade
		*/
		public function run($info, $phase, $installtype = 'install')
		{
			if (is_array($info) && isset($info['key']) && isset($info['secret']))
			{
				if (isset($_SERVER['HOME']))
				{
					$homeDir = $_SERVER['HOME'];
				}
				else
				{
					$homeDir = shell_exec('echo $HOME 2>&1');
				}
			
				file_put_contents($homeDir . '/.testingbot', $info['key'] . ':' . $info['secret']);
				echo "Your account has been configured successfully. You can now start to run your Selenium tests.\n";
			}
			else
			{
				echo "Please fill in both your testingbot.com api key and secret\n";
			}
			return true;
		}
	}