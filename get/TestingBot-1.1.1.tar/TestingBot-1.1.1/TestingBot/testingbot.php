#!/usr/bin/env php
<?php

	class TestingBot_testingbot_postinstall
	{
		var $_ui;
		var $_config;
		
		/**
		* @param PEAR_Config
		* @param PEAR_Frontend
		*/
		public function init(&$config, &$ui)
		{
			$this->_config = &$config;
			$this->_ui = &$ui;
			
			return true;
		}

		/**
		* @param array associative array of parameters
		* @param string paramgroup name
		* @param string either install or upgrade
		*/
		public function run($info, $phase, $installtype = 'install')
		{
			if (is_array($info) && isset($info['key']) && isset($info['secret']))
			{
				if (isset($_SERVER['HOME']))
				{
					$homeDir = $_SERVER['HOME'];
				}
				else
				{
					$homeDir = shell_exec('echo $HOME 2>&1');
				}
			
				file_put_contents($homeDir . '/.testingbot', $info['key'] . ':' . $info['secret']);
				echo "Your account has been configured successfully. You can now start to run your Selenium tests.\n";
			}
			return true;
		}
	}
	
	
	
	if (!defined('STDIN')) 
	{
		die('Please run this script in a shell/cli.');
	}
	
	$version = '1.0.0';
	
	function displayHelp()
	{
		global $version;
		echo "*** TestingBot v.$version http://www.testingbot.com ***\nThese commands are available:
		\nhelp\t\tdisplays this list
		\rversion\t\tcurrent version
		\rconfigure\tconfigure \"API_KEY:API_SECRET\"\n";
	}
	
	function configure()
	{
		global $argv;
	
		if (sizeof($argv) < 3)
		{
			die("Please use configure \"API_KEY:API_SECRET\"\n");
		}
	
		if (isset($_SERVER['HOME']))
		{
			$homeDir = $_SERVER['HOME'];
		}
		else
		{
			$homeDir = shell_exec('echo $HOME 2>&1');
		}
	
		file_put_contents($homeDir . '/.testingbot', $argv[2]);
		echo "Your account has been configured successfully. You can now start to run your Selenium tests.\n";
	}
	
	if (sizeof($argv) === 1)
	{
		displayHelp();
	}
	
	if (sizeof($argv) > 1)
	{
		switch ($argv[1]) 
		{
			default:
			case 'help':
				displayHelp();
				break;
			case 'configure':
				configure();
				break;
			case 'version':
				echo "Version v.$version http://www.testingbot.com\n";
		}
	}